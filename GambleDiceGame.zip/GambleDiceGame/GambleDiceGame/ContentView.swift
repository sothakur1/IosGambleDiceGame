//
//  ContentView.swift
//  GambleDiceGame
//
//  Created by Sohan Ramesh Thakur on 2/14/24.
//

import SwiftUI

struct ContentView: View {
    //wil declare variables
    @State var sum: Int = 0
    @State var sumOfMoney: Int = 0
    @State var total: String = ""
    @State var totalMon: String = "0"
    @State var roundCount: Int = 0
    @State var roundCt: String = ""
    
    @State var sliderGambleValue: Double = 0
    @State var showAlert = false
    @State var resetShowAlert = false
    
    @State var p1 = 1
    @State var p2 = 1
    @State var p3 = 1
    @State var p4 = 1
    
    @State var minimumSum = 0
    @State var maximumSum = 0
    
    var imagesToDisplay = [1: "Dice1", 2: "Dice2", 3:"Dice3", 4: "Dice4", 5: "Dice5", 6: "Dice6"]
    
    
    var body: some View {
        NavigationView{
            ScrollView {
                VStack{
                    
                    Text("Welcome to The Dice Game!! Try your luck")
                        .font(.largeTitle).fontWeight(.heavy)
                    
                    HStack{
                        Text("Your Total Money:")
                        TextField("1",text: $totalMon)
                    }.padding([.horizontal],15)
                    
                    
                    HStack {
                        //to get the deafu imgaes of four dice
                        VStack {
                            Image(imagesToDisplay[p1]!).resizable().aspectRatio(contentMode: .fit)
                                .frame(maxWidth: 150)
                            Text(String(p1))
                            Image(imagesToDisplay[p2]!).resizable().aspectRatio(contentMode: .fit)
                                .frame(maxWidth: 150)
                            Text(String(p2))
                        }
                        
                        VStack {
                            Image(imagesToDisplay[p3]!).resizable().aspectRatio(contentMode: .fit)
                                .frame(maxWidth: 150)
                            Text(String(p3))
                            Image(imagesToDisplay[p4]!).resizable().aspectRatio(contentMode: .fit)
                                .frame(maxWidth: 150)
                            Text(String(p4))
                        }
                    }.padding()
                    
                    
                    //logic to mention total sum and slider for gambling
                    HStack{
                        Text("Sum: ").padding(.leading, 20)
                        TextField("0", text: $total)
                        Spacer()
                        Text("Round: ").padding(.leading, 48)
                        TextField("0", text: $roundCt)
                    }.frame(maxWidth: .infinity)
                    
                    Slider(value: $sliderGambleValue, in: 0...36, step: 1){
                        Text("Speed")
                    }minimumValueLabel: {
                        Text("0").font(.title2).fontWeight(.thin)
                    }maximumValueLabel: {
                        Text("36").font(.title2).fontWeight(.thin)
                    }.padding([.horizontal],20)
                    Text("\(Int(sliderGambleValue))")
                    
                    
                    HStack(spacing: 250){
                        //logic to display alert for a situation while thrwoing the dice which follow rule 1 of the game
                        if($sliderGambleValue.wrappedValue == 0){
                            Button("Roll", action: {
                                showAlert = true
                            }).alert("Hey, don't rush!!First set the Bet on slider", isPresented: $showAlert){
                                Button("Cool", role: .cancel){}
                            }
                        }else{
                            Button("Roll", action:{
                                p1 = Int.random(in: 1...6)
                                p2 = Int.random(in: 1...6)
                                p3 = Int.random(in: 1...6)
                                p4 = Int.random(in: 1...6)
                                
                                sum = p1+p2+p3+p4
                                total = String(sum)
                                minimumSum = sum - 2
                                maximumSum = sum + 2
                                roundCount = roundCount + 1
                                roundCt = String(roundCount)
                                //Second Rule
                                if(Int(sliderGambleValue) == sum){
                                    sumOfMoney += 100
                                    totalMon = String(sumOfMoney)
                                }
                                
                                //Third Rule
                                else if(Int(sliderGambleValue) >= minimumSum && Int(sliderGambleValue) <= maximumSum){
                                    sumOfMoney += 50
                                    totalMon = String(sumOfMoney)
                                    
                                }
                            })
                            
                        }
                        
                        
                        
                        Button("Reset", action: {
                            sliderGambleValue = 0
                            sum = 0
                            sumOfMoney = 0
                            totalMon = "0"
                            total = "0"
                            p1 = 1
                            p2 = 1
                            p3 = 1
                            p4 = 1
                            
                            roundCount = 0
                            roundCt = "0"
                            resetShowAlert = true
                            }).alert("Game will reset now!! Here We Go...",isPresented:$resetShowAlert) {
                                Button("OK", role: .cancel) {}
                            }
                    } //250
                    
                    //logic to navigate to Rule page of our Game
                    
                    NavigationLink(destination: RulePageView())
                    {
                        Text("Should I guide you? Go to Game Rules")
                            .font(.title3).colorMultiply(.indigo)
                    }
                    Spacer()
                    //logic to check author's profile
                    NavigationLink(destination: AuthorDescriptionView())
                    {
                        Text("About Author").font(.title3).colorMultiply(.indigo)
                    }
                }.frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: .infinity)
                    .background(CustomColor.myBackColor)
            }
         
        }
    }
}

struct ContentView_Preview: PreviewProvider{
    static var previews: some View{
        ContentView()
    }
}

struct CustomColor{
    static let myBackColor = Color("backgroundForProfile")
}
