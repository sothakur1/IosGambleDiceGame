//
//  GambleDiceGameApp.swift
//  GambleDiceGame
//
//  Created by Sohan Ramesh Thakur on 2/14/24.
//

import SwiftUI

@main
struct GambleDiceGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
