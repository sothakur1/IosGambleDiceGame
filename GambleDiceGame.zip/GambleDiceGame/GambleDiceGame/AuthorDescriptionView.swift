//
//  AuthorDescriptionView.swift
//  GambleDiceGame
//
//  Created by Sohan Ramesh Thakur on 2/14/24.
//

import SwiftUI

struct AuthorDescriptionView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showingAlert = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .center, spacing: 10) {
                    // Author for the Profile Image
                    Image("AuthorProfilePic")
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                        .shadow(radius: 10)
                        .overlay(Circle().stroke(Color.white, lineWidth: 4))
                        .padding()
                        .frame(maxWidth: 300)

                    // Author's Name
                    Text(authObj.name)
                        .font(.custom("Georgia", size: 20))
                        .padding()

                    // Author's Description
                    Text(authObj.description)
                        .font(.custom("Avenir Next", size: 15))
                        .multilineTextAlignment(.center)
                        .padding()

                    // Play Now Button
                    Button("Play Now") {
                        showingAlert = true
                    }
                    .alert(isPresented: $showingAlert) {
                        Alert(title: Text("Let's Gooo!!!"),
                              dismissButton: .default(Text("Ok")) {
                                presentationMode.wrappedValue.dismiss()
                              })
                    }
                }
            }
            .navigationBarTitle(Text("Author Profile"), displayMode: .inline)
            .background(ACustomColor.myColor)
        }
    }
}
//Class and Object for Name and Description
class Author{
    var name = "Sohan Thakur"
    var description = " Hello! I'm a computer science graduate with expertise in software development (with 4+ years of full time experience ) specifically in backend in .netCore,Angular8 in frontend and Azure for cloud computing.  In my leisure time, I'm passionate about delving into emerging technologies and dedicating myself to personal projects. Beyond the realm of tech, I find joy in engaging in various sports activities, expressing myself through dance, and capturing the world around me through sketching.."
}
let authObj = Author()

struct AuthorView_Previews: PreviewProvider {
    static var previews: some View {
        AuthorDescriptionView()
    }
}

//Code for Custom Background Color
struct ACustomColor {
    static let myColor = Color("myColor")
}
