//
//  RulePageView.swift
//  GambleDiceGame
//
//  Created by Sohan Ramesh Thakur on 2/14/24.
//

import SwiftUI
import UIKit

struct RulePageView: View {
    var body: some View {
        ScrollView {
            // Code for Game Rules
            VStack(alignment: .leading, spacing: 20) {
                
                Image("RuleImage")
                    .resizable()
                    .scaledToFit() // To makesure that the image scales nicely within the given frame
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 400, height: 200)
                    Spacer()
                    
                
                ForEach(Rules.all, id: \.self) { rule in
                    Text(rule)
                        .padding(.horizontal, 28)
                        .foregroundColor(Color.pink)
                        .font(.custom("Avenir Next", size: 20))
                        .multilineTextAlignment(.leading) // To have more control, we have used leading alignment
                }
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color("myColor"))
            .navigationBarTitle("Game Rules", displayMode: .inline)
        }
    }
}

struct Rules {
    static let all = [
        "1. Players are required to adjust the slider to set their bet amount before they can press the roll button.",
        "2. Players will be awarded 100 points if the total of the rolled dice exactly equals their wager.",
        "3. Should the total from the dice roll come within a margin of plus or minus two from the bet, the player will gain 50 points."
    ]
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        RulePageView()
    }
}
//Code for Custom Background Color
struct RCustomColor {
    static let myColor = Color("backgroundForProfile")
}

